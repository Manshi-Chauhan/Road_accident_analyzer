import matplotlib.pyplot as plt
import pandas as pd

data = pd.read_csv("accident_data.csv", sep='\t')
data = data.dropna()

fig = plt.figure(figsize=(30, 22))
fig.suptitle('Road Accident Analysis Dashboard', fontsize=24, fontweight='bold', y=0.996)

gs = fig.add_gridspec(3, 3,
                      top=0.88, bottom=0.06,
                      left=0.07, right=0.97,
                      hspace=0.75, wspace=0.42)

# 1. Weather Conditions - Full top row (Bar)
ax1 = fig.add_subplot(gs[0, :])
weather = data['Weather Conditions'].value_counts()
ax1.bar(weather.index, weather.values, color='steelblue')
ax1.set_title('Accidents by Weather Conditions', fontsize=14, pad=12)
ax1.set_xlabel('Weather', fontsize=11)
ax1.set_ylabel('Count', fontsize=11)
ax1.tick_params(axis='x', rotation=20, labelsize=10)

# 2. Road Type - Bar
ax2 = fig.add_subplot(gs[1, 0])
road_type = data['Road Type'].value_counts()
ax2.bar(range(len(road_type)), road_type.values, color='coral')
ax2.set_xticks(range(len(road_type)))
ax2.set_xticklabels(road_type.index, fontsize=8, rotation=15)
ax2.set_title('Road Type', fontsize=12, pad=10)
ax2.set_ylabel('Count')

# 3. Lighting Conditions - Pie
ax3 = fig.add_subplot(gs[1, 1])
light = data['Lighting Conditions'].value_counts()
wedges, _, autotexts = ax3.pie(
    light.values, labels=None, autopct='%1.1f%%',
    textprops={'fontsize': 9}, radius=0.85, pctdistance=0.78
)
ax3.legend(wedges, light.index, loc='lower center',
           bbox_to_anchor=(0.5, -0.22), ncol=2, fontsize=8)
ax3.set_title('Lighting Conditions', fontsize=12, pad=10)

# 4. Traffic Control - Bar
ax4 = fig.add_subplot(gs[1, 2])
traffic = data['Traffic Control Presence'].value_counts()
ax4.bar(range(len(traffic)), traffic.values, color='mediumseagreen')
ax4.set_xticks(range(len(traffic)))
ax4.set_xticklabels(traffic.index, fontsize=8, rotation=15)
ax4.set_title('Traffic Control', fontsize=12, pad=10)
ax4.set_ylabel('Count')

# 5. Road Condition - Pie
ax5 = fig.add_subplot(gs[2, 0])
road = data['Road Condition'].value_counts()
wedges2, _, _ = ax5.pie(
    road.values, labels=None, autopct='%1.1f%%',
    textprops={'fontsize': 9}, radius=0.85, pctdistance=0.78
)
ax5.legend(wedges2, road.index, loc='lower center',
           bbox_to_anchor=(0.5, -0.22), ncol=2, fontsize=8)
ax5.set_title('Road Condition', fontsize=12, pad=10)

# 6. Driver License Status - Bar
ax6 = fig.add_subplot(gs[2, 1])
license_data = data['Driver License Status'].value_counts()
ax6.bar(range(len(license_data)), license_data.values, color='mediumpurple')
ax6.set_xticks(range(len(license_data)))
ax6.set_xticklabels(license_data.index, fontsize=8, rotation=15)
ax6.set_title('License Status', fontsize=12, pad=10)
ax6.set_ylabel('Count')

# 7. Driver Gender - Donut
ax7 = fig.add_subplot(gs[2, 2])
gender = data['Driver Gender'].value_counts()
wedges3, _, autotexts3 = ax7.pie(
    gender.values, labels=None,
    wedgeprops={'width': 0.5}, autopct='%1.1f%%',
    textprops={'fontsize': 9}, radius=0.85, pctdistance=0.75
)
ax7.legend(wedges3, gender.index, loc='lower center',
           bbox_to_anchor=(0.5, -0.15), ncol=2, fontsize=9)
ax7.set_title('Driver Gender', fontsize=12, pad=10)

#plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.savefig('dashboard.png', dpi=150, bbox_inches='tight')
plt.show()